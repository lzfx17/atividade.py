def _setup(client):
    """Cria cliente e produto base para os testes."""
    client.post("/clientes", json={"cpf": "12345678900", "nome": "Joao"})
    client.post("/produtos", json={"codigo": 1, "valor": 10.0, "tipo": 2})


def _criar_pedido(client) -> int:
    r = client.post(
        "/lanchonete/pedidos",
        json={"cpf": "12345678900", "cod_produto": 1, "qtd_max_produtos": 5},
    )
    return r.json()["codigo"]


def test_deve_tornar_pedido_prioritario(client):
    """Verifica o fluxo feliz de marcar um pedido como prioritário."""
    _setup(client)
    cod = _criar_pedido(client)

    response = client.post(f"/lanchonete/pedidos/{cod}/prioridade")

    assert response.status_code == 200
    data = response.json()
    assert data["ok"] is True
    assert data["mensagem"] == "Pedido marcado como prioritário"


def test_nao_deve_priorizar_pedido_cancelado(client):
    """Pedido cancelado não pode ser marcado como prioritário."""
    _setup(client)
    cod = _criar_pedido(client)
    client.patch(f"/lanchonete/pedidos/{cod}/cancelar")

    response = client.post(f"/lanchonete/pedidos/{cod}/prioridade")

    assert response.status_code == 400


def test_nao_deve_priorizar_pedido_inexistente(client):
    """Pedido inexistente retorna erro ao tentar priorizar."""
    response = client.post("/lanchonete/pedidos/999/prioridade")
    assert response.status_code == 400


def test_fila_deve_ter_prioritarios_primeiro(client):
    """Pedidos prioritários devem aparecer antes dos normais na fila."""
    _setup(client)
    cod1 = _criar_pedido(client)
    cod2 = _criar_pedido(client)
    cod3 = _criar_pedido(client)

    client.post(f"/lanchonete/pedidos/{cod2}/prioridade")

    response = client.get("/lanchonete/pedidos/fila/preparo")
    assert response.status_code == 200

    fila = response.json()
    codigos = [p["codigo"] for p in fila]

    assert codigos[0] == cod2
    assert cod1 in codigos
    assert cod3 in codigos


def test_fila_nao_deve_listar_cancelados(client):
    """Pedidos cancelados não aparecem na fila de preparo."""
    _setup(client)
    cod1 = _criar_pedido(client)
    cod2 = _criar_pedido(client)
    client.patch(f"/lanchonete/pedidos/{cod1}/cancelar")

    response = client.get("/lanchonete/pedidos/fila/preparo")
    assert response.status_code == 200

    codigos = [p["codigo"] for p in response.json()]
    assert cod1 not in codigos
    assert cod2 in codigos


def test_fila_nao_deve_listar_entregues(client):
    """Pedidos finalizados não aparecem na fila de preparo."""
    _setup(client)
    cod1 = _criar_pedido(client)
    cod2 = _criar_pedido(client)
    client.post(f"/lanchonete/pedidos/{cod1}/finalizar")

    response = client.get("/lanchonete/pedidos/fila/preparo")
    assert response.status_code == 200

    codigos = [p["codigo"] for p in response.json()]
    assert cod1 not in codigos
    assert cod2 in codigos
